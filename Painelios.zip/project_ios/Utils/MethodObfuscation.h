#import "VariableObfuscation.h"

#ifndef MethodObfuscation_h

#define MethodObfuscation_h
//confuse string at Sat Jun  1 12:22:36 +07 2024
#define ImGuiDrawView RRnOwkhBjlDCnoqjhqjQ
#define showChange FWBwynoreHMvFPjuQkTf
#define isMenuShowing GmmtbwBOlBYaQRpBHDVm
#define updateIOWithTouchEvent IPnEfSYzNRGgJrXEocNJ
#define MenuLoad tXGBBDJNKKzPYcSGmlav
#define MenuInteraction kdgovOiKdLgyHlHZTbgV
#define didFinishLaunching LQZnOaXVNEaDtNZvzTae
#endif
